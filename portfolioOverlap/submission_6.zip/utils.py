import json
import requests

URL_TO_FETCH_FUNDS = "https://geektrust.s3.ap-southeast-1.amazonaws.com/"
URL_TO_FETCH_FUNDS += "portfolio-overlap/stock_data.json"


def get_funds():
    response = requests.get(URL_TO_FETCH_FUNDS)
    data = json.loads(response.content)
    data = data['funds']
    funds = {}
    for fund in data:
        funds[fund['name']] = fund['stocks']
    return funds


def get_cmd(line):
    if line[-1] == '\n':
        line = line[:-1]
    cmd = line.split(' ')
    return cmd


def read_input(input_file):
    with open(input_file) as file:
        return file.readlines()


def is_calculate_overlap(op):
    return op == "CALCULATE_OVERLAP"


def is_add_stocks(op):
    return op == "ADD_STOCK"


def check_fund_exist(funds, fund_name):
    if fund_name not in funds:
        raise Exception("FUND_NOT_FOUND")


def calculate_overlap(funds, fund_a, fund_b):
    no_of_common_stocks = 0
    no_of_stocks_in_a = len(funds[fund_a])
    no_of_stocks_in_b = len(funds[fund_b])

    for stocks in funds[fund_a]:
        if stocks in funds[fund_b]:
            no_of_common_stocks += 1

    percent_overlap = (2 * no_of_common_stocks) * 100
    percent_overlap /= (no_of_stocks_in_a + no_of_stocks_in_b)

    return percent_overlap


def add_stock(funds, fund, stock):
    funds[fund].append(stock)


def get_portfolio(line):
    cmd = get_cmd(line)
    return cmd[1:]


def fetch_stock_name(cmd):
    return ' '.join(cmd[2:])


def calculate_overlap_portfolio(portfolio, funds, fund_name):
    for fund in portfolio:
        percent_overlap = calculate_overlap(funds, fund, fund_name)
        if percent_overlap > 0:
            print(fund_name + " " + fund + " " + "{:.2f}".format(
                round(percent_overlap, 2)) + "%")