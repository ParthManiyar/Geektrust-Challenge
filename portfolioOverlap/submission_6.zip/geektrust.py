import sys
from utils import get_funds, get_cmd, get_portfolio, read_input, \
    is_calculate_overlap, is_add_stocks, check_fund_exist, \
    calculate_overlap_portfolio, fetch_stock_name, add_stock


def main():
    input_file = sys.argv[1]
    funds = get_funds()
    lines = read_input(input_file)
    portfolio = get_portfolio(lines[0])
    lines = lines[1:]
    for line in lines:
        try:
            cmd = get_cmd(line)
            op = cmd[0]
            if is_calculate_overlap(op):
                fund_name = cmd[1]
                check_fund_exist(funds, fund_name)
                calculate_overlap_portfolio(portfolio, funds, fund_name)
            elif is_add_stocks(op):
                fund_name = cmd[1]
                check_fund_exist(funds, fund_name)
                stock_name = fetch_stock_name(cmd)
                add_stock(funds, fund_name, stock_name)
            else:
                print("INVALID_OPERATION")
        except Exception as e:
            print(e)


if __name__ == "__main__":
    main()
