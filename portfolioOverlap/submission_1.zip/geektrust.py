import json

import requests
import sys


def main():
    input_file = sys.argv[1]
    resp = requests.get("https://geektrust.s3.ap-southeast-1.amazonaws.com"
                        "/portfolio-overlap/stock_data.json")
    data = json.loads(resp.content)
    data = data['funds']
    funds = {}
    for fund in data:
        funds[fund['name']] = fund['stocks']
    with open(input_file) as file:
        lines = file.readlines()
        for line in lines:
            if line[-1] == '\n':
                line = line[:-1]
            line = line.split(' ')
            operation = line[0]
            if operation == "CALCULATE_OVERLAP":
                fund_name = line[1]
                if fund_name not in funds:
                    print("FUND_NOT_FOUND")
                else:
                    for fund in portfolio:
                        no_of_common_stocks = 0
                        for stocks in funds[fund]:
                            if stocks in funds[fund_name]:
                                no_of_common_stocks += 1
                        if no_of_common_stocks != 0:
                            percentage = ((2*no_of_common_stocks) / (len(funds[fund]) + len(funds[fund_name])))*100
                            print(fund_name + " " + fund + " " + "{:.2f}".format(round(percentage,2))+"%")

            elif operation == "ADD_STOCK":
                fund_name = line[1]
                if fund_name not in funds:
                    print("FUND_NOT_FOUND")
                else:
                    stock_name = ''.join(line[2:])
                    funds[fund_name].append(stock_name)
            elif operation == "CURRENT_PORTFOLIO":
                portfolio = line[1:]
            else:
                new_funds = line
                for fund in new_funds:
                    portfolio.append(fund)


if __name__ == "__main__":
    main()
