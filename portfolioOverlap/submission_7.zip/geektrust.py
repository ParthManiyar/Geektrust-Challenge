import sys
from utils import get_funds, get_cmd, get_portfolio, read_input, \
    is_calculate_overlap, is_add_stocks, get_fund,  fetch_stock_name


def main():
    input_file = sys.argv[1]
    funds = get_funds()
    lines = read_input(input_file)
    portfolio = get_portfolio(funds, lines[0])
    lines = lines[1:]
    for line in lines:
        try:
            cmd = get_cmd(line)
            op = cmd[0]
            if is_calculate_overlap(op):
                fund_name = cmd[1]
                fund = get_fund(funds, fund_name)
                portfolio.calculate_overlap(fund)
            elif is_add_stocks(op):
                fund_name = cmd[1]
                fund = get_fund(funds, fund_name)
                stock_name = fetch_stock_name(cmd)
                fund.add_stock(stock_name)
            else:
                print("INVALID_OPERATION")
        except Exception as e:
            print(e)


if __name__ == "__main__":
    main()
