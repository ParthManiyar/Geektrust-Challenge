import sys
from utils import create_portfolio, parse_input_change, sanitize_input


def main():
    input_file = sys.argv[1]
    with open(input_file) as f:
        line_1 = f.readline()
        line_2 = f.readline()
        portfolio_obj = create_portfolio(line_1, line_2)
        lines = f.readlines()
        for line in lines:
            line = sanitize_input(line)
            if line[0] == 'CHANGE':
                change_equity, change_debt, change_gold, month = \
                    parse_input_change(line)
                portfolio_obj.change(change_equity, change_debt, change_gold,
                                     month)
            elif line[0] == 'BALANCE':
                month = line[1]
                balance = portfolio_obj.balance(month)
                print(str(int(balance['equity']))
                      + " " + str(int(balance['debt']))
                      + " " + str(int(balance['gold'])))
            elif line[0] == 'REBALANCE':
                print(portfolio_obj.last_rebalance())


if __name__ == "__main__":
    main()
