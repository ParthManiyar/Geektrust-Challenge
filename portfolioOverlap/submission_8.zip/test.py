import unittest
from geektrust import execute_cmd
from utils import get_funds, read_input, get_portfolio, get_cmd


class TestAppMethods(unittest.TestCase):

    def test_app(self):
        input_file = "input.txt"
        funds = get_funds()
        lines = read_input(input_file)
        portfolio = get_portfolio(funds, lines[0])
        lines = lines[1:]
        with open("output.txt") as f:
            for line in lines:
                cmd = get_cmd(line)
                output = execute_cmd(funds, portfolio, cmd)
                for o in output:
                    li = f.readline()
                    if li[-1] == '\n':
                        li = li[:-1]
                    self.assertEqual(li, str(o))


if __name__ == '__main__':
    unittest.main()
